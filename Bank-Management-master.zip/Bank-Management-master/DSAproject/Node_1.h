#pragma once
#pragma once
class Node_1
{
public:
	Node_1 * next;
	int accountNumber;
	int password;
	Node_1();
	Node_1(int, int);
};