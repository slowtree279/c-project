# Bank-Management
In this project there a three basic portions:
1-admin
2-customer
3-staff
so all these have different levels of authorizations like 

1-customer can :
perform transaction and like that

3-staff can:
add amount in account
deduct amount from account
request to open account

3-admin can:
see all accounts 
can read all accounts
can give permission to open account
have cresidentials of all accounts
